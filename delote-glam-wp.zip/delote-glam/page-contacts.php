<?php
/*
Template Name: Page Contacts
*/
get_header();
?>
<!-- // Add custom options in customizer -->
<?php $custom_options_theme = custom_options_theme(); ?>

<main class="main-wrapper main-top">
    <section class="contacts section-top">
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell">
                    <div class="title">
                        <h1 class="title__wrap"><?php the_title(); ?></h1>
                    </div>
                </div>
            </div>
        </div>
        <div class="contacts__container grid-container">
            <div class="grid-x grid-padding-x">
                <?php
                    $show_footer_contacts = false;
                    if ( ! empty( $custom_options_theme['title_for_contacts'] ) ) {
                        $show_footer_contacts = true;
                    }
                    if ( ! empty( $custom_options_theme['phone_1'] ) || ! empty( $custom_options_theme['phone_2'] ) || ( ! empty( $custom_options_theme['address_name'] ) && ! empty( $custom_options_theme['address_link'] ) ) ) {
                        $show_footer_contacts = true;
                    }
                    ?>
                <?php if ( $show_footer_contacts ) : ?>
                <div class="cell small-12 medium-6 large-4">
                    <div class="footer__wrap">
                        <?php if ( ! empty( $custom_options_theme['title_for_contacts'] ) ): ?>
                        <h4 class="footer__title contacts__title">
                            <?php echo esc_html( $custom_options_theme['title_for_contacts'] ); ?></h4>
                        <?php endif; ?>
                        <nav class="contacts__nav footer__nav">
                            <ul class="footer__items">
                                <?php if ( ! empty( $custom_options_theme['phone_1'] ) ): ?>
                                <li class="footer__item">
                                    <a href="tel:+<?php echo preg_replace( '/[^\d]/', '', $custom_options_theme['phone_1'] ); ?>"
                                        class="footer__link">
                                        <?php echo $custom_options_theme['phone_1']; ?>
                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php if ( ! empty( $custom_options_theme['phone_2'] ) ): ?>
                                <li class="footer__item">
                                    <a href="tel:+<?php echo preg_replace( '/[^\d]/', '', $custom_options_theme['phone_2'] ); ?>"
                                        class="footer__link">
                                        <?php echo $custom_options_theme['phone_2']; ?>
                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php if ( ! empty( $custom_options_theme['address_name'] ) && ! empty( $custom_options_theme['address_link'] ) ): ?>
                                <li class="footer__item">
                                    <a href="<?php echo esc_url( $custom_options_theme['address_link'] ); ?>"
                                        class="footer__link" target="_blank">
                                        <?php echo esc_html( $custom_options_theme['address_name'] ); ?>
                                    </a>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                </div>
                <?php endif; ?>
                <?php
                    $show_work_hours = false;
                    if ( ! empty( $custom_options_theme['work_hours_title'] ) ) {
                        $show_work_hours = true;
                    }
                    if ( ! empty( $custom_options_theme['work_hours_weekdays'] ) || ! empty( $custom_options_theme['work_hours_weekends'] ) ) {
                        $show_work_hours = true;
                    }
                    ?>
                <?php if ( $show_work_hours ) : ?>
                <div class="cell small-12 medium-6 large-4">
                    <div class="footer__wrap">
                        <?php if ( ! empty( $custom_options_theme['work_hours_title'] ) ): ?>
                        <h4 class="footer__title contacts__title">
                            <?php echo esc_html( $custom_options_theme['work_hours_title'] ); ?></h4>
                        <?php endif; ?>
                        <nav class="contacts__nav footer__nav">
                            <ul class="footer__items">
                                <?php if ( ! empty( $custom_options_theme['work_hours_weekdays'] ) ): ?>
                                <li class="footer__item">
                                    <p class="footer__text">
                                        <?php echo esc_html( $custom_options_theme['work_hours_weekdays'] ); ?></p>
                                </li>
                                <?php endif; ?>
                                <?php if ( ! empty( $custom_options_theme['work_hours_weekends'] ) ): ?>
                                <li class="footer__item">
                                    <p class="footer__text">
                                        <?php echo esc_html( $custom_options_theme['work_hours_weekends'] ); ?></p>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                </div>
                <?php endif; ?>
                <?php
                    $show_socials = false;
                    if ( ! empty( $custom_options_theme['instagram'] ) || ! empty( $custom_options_theme['tiktok'] ) || ! empty( $custom_options_theme['facebook'] ) ) {
                        $show_socials = true;
                    }
                    ?>
                <?php if ( $show_socials ) : ?>
                <div class="cell small-12 medium-12 large-4">
                    <div class="footer__wrap">
                        <?php if ( ! empty( $custom_options_theme['title_for_social_media'] ) ): ?>
                        <h4 class="footer__title contacts__title">
                            <?php echo esc_html( $custom_options_theme['title_for_social_media'] ); ?></h4>
                        <?php endif; ?>
                        <nav class="contacts__nav footer__nav">
                            <ul class="contacts__socials socials">
                                <?php if ( ! empty( $custom_options_theme['instagram'] ) ): ?>
                                <li class="socials__item">
                                    <a href="<?php echo esc_url( $custom_options_theme['instagram'] ); ?>"
                                        class="socials__link" target="_blank">
                                        <i class="fa-brands fa-instagram"></i>
                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php if ( ! empty( $custom_options_theme['tiktok'] ) ): ?>
                                <li class="socials__item">
                                    <a href="<?php echo esc_url( $custom_options_theme['tiktok'] ); ?>"
                                        class="socials__link" target="_blank">
                                        <i class="fa-brands fa-tiktok"></i>
                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php if ( ! empty( $custom_options_theme['facebook'] ) ): ?>
                                <li class="socials__item">
                                    <a href="<?php echo esc_url( $custom_options_theme['facebook'] ); ?>"
                                        class="socials__link" target="_blank">
                                        <i class="fa-brands fa-facebook-f"></i>
                                    </a>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                </div>
                <?php endif; ?>
                <div class="cell small-12 medium-12 large-12">
                    <div id="map" class="contacts__map map"></div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php
    // Output the page content
    the_content();
?>

<?php get_footer(); ?>