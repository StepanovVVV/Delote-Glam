<!-- // Add custom options in customizer -->
<?php $custom_options_theme = custom_options_theme(); ?>

<footer class="footer">
        <div class="footer__container grid-container">
            <div class="grid-x grid-padding-x">
                <?php
                    $show_footer_logo = false;
                    $custom_logo_id = get_theme_mod( 'custom_logo' );
                    if ( $custom_logo_id ) {
                        $show_footer_logo = true;
                    } else {
                        if ( ! empty( get_bloginfo( 'name' ) ) ) {
                            $show_footer_logo = true;
                        }
                    }
                ?>

                <?php if ( $show_footer_logo ) : ?>
                    <div class="cell small-12 medium-6 large-2">
                        <div class="footer__wrap">
                            <a href="<?php echo home_url( '/' ); ?>" class="footer__logo">
                                <?php
                                if ( $custom_logo_id ) :
                                    $logo_url = wp_get_attachment_image_src( $custom_logo_id, 'full' );
                                    if ( $logo_url ) : ?>
                                        <img src="<?php echo esc_url( $logo_url[0] ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" />
                                    <?php endif; ?>
                                <?php else : ?>
                                    <h2 class="footer__title"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></h2>
                                <?php endif; ?>
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
                <?php
                    $show_footer_contacts = false;
                    if ( ! empty( $custom_options_theme['title_for_contacts'] ) ) {
                        $show_footer_contacts = true;
                    }
                    if ( ! empty( $custom_options_theme['phone_1'] ) || ! empty( $custom_options_theme['phone_2'] ) || ( ! empty( $custom_options_theme['address_name'] ) && ! empty( $custom_options_theme['address_link'] ) ) ) {
                        $show_footer_contacts = true;
                    }
                    ?>
                <?php if ( $show_footer_contacts ) : ?>
                    <div class="cell small-12 medium-6 large-4">
                        <div class="footer__wrap">
                            <?php if ( ! empty( $custom_options_theme['title_for_contacts'] ) ): ?>
                                <h4 class="footer__title"><?php echo esc_html( $custom_options_theme['title_for_contacts'] ); ?></h4>
                            <?php endif; ?>
                            <nav class="footer__nav">
                                <ul class="footer__items">
                                    <?php if ( ! empty( $custom_options_theme['phone_1'] ) ): ?>
                                        <li class="footer__item">
                                            <a href="tel:+<?php echo preg_replace( '/[^\d]/', '', $custom_options_theme['phone_1'] ); ?>" class="footer__link">
                                                <?php echo $custom_options_theme['phone_1']; ?>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if ( ! empty( $custom_options_theme['phone_2'] ) ): ?>
                                        <li class="footer__item">
                                            <a href="tel:+<?php echo preg_replace( '/[^\d]/', '', $custom_options_theme['phone_2'] ); ?>" class="footer__link">
                                                <?php echo $custom_options_theme['phone_2']; ?>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if ( ! empty( $custom_options_theme['address_name'] ) && ! empty( $custom_options_theme['address_link'] ) ): ?>
                                        <li class="footer__item">
                                            <a href="<?php echo esc_url( $custom_options_theme['address_link'] ); ?>" class="footer__link" target="_blank">
                                                <?php echo esc_html( $custom_options_theme['address_name'] ); ?>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </nav>
                        </div>
                    </div>
                <?php endif; ?>
                <?php
                    $show_work_hours = false;
                    if ( ! empty( $custom_options_theme['work_hours_title'] ) ) {
                        $show_work_hours = true;
                    }
                    if ( ! empty( $custom_options_theme['work_hours_weekdays'] ) || ! empty( $custom_options_theme['work_hours_weekends'] ) ) {
                        $show_work_hours = true;
                    }
                    ?>
                    <?php if ( $show_work_hours ) : ?>
                        <div class="cell small-12 medium-6 large-3">
                            <div class="footer__wrap">
                                <?php if ( ! empty( $custom_options_theme['work_hours_title'] ) ): ?>
                                    <h4 class="footer__title"><?php echo esc_html( $custom_options_theme['work_hours_title'] ); ?></h4>
                                <?php endif; ?>
                                <nav class="footer__nav">
                                    <ul class="footer__items">
                                        <?php if ( ! empty( $custom_options_theme['work_hours_weekdays'] ) ): ?>
                                            <li class="footer__item">
                                                <p class="footer__text"><?php echo esc_html( $custom_options_theme['work_hours_weekdays'] ); ?></p>
                                            </li>
                                        <?php endif; ?>
                                        <?php if ( ! empty( $custom_options_theme['work_hours_weekends'] ) ): ?>
                                            <li class="footer__item">
                                                <p class="footer__text"><?php echo esc_html( $custom_options_theme['work_hours_weekends'] ); ?></p>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php
                        $show_socials = false;
                        if ( ! empty( $custom_options_theme['instagram'] ) || ! empty( $custom_options_theme['tiktok'] ) || ! empty( $custom_options_theme['facebook'] ) ) {
                            $show_socials = true;
                        }
                        ?>
                    <?php if ( $show_socials ) : ?>
                        <div class="cell small-12 medium-6 large-3">
                            <div class="footer__wrap">
                                <div class="footer__socials">
                                    <?php if ( ! empty( $custom_options_theme['title_for_social_media'] ) ): ?>
                                        <h4 class="footer__title"><?php echo esc_html( $custom_options_theme['title_for_social_media'] ); ?></h4>
                                    <?php endif; ?>
                                    <nav class="footer__nav">
                                        <ul class="socials">
                                            <?php if ( ! empty( $custom_options_theme['instagram'] ) ): ?>
                                                <li class="socials__item">
                                                    <a href="<?php echo esc_url( $custom_options_theme['instagram'] ); ?>" class="socials__link" target="_blank">
                                                        <i class="fa-brands fa-instagram"></i>
                                                    </a>
                                                </li>
                                            <?php endif; ?>
                                            <?php if ( ! empty( $custom_options_theme['tiktok'] ) ): ?>
                                                <li class="socials__item">
                                                    <a href="<?php echo esc_url( $custom_options_theme['tiktok'] ); ?>" class="socials__link" target="_blank">
                                                        <i class="fa-brands fa-tiktok"></i>
                                                    </a>
                                                </li>
                                            <?php endif; ?>
                                            <?php if ( ! empty( $custom_options_theme['facebook'] ) ): ?>
                                                <li class="socials__item">
                                                    <a href="<?php echo esc_url( $custom_options_theme['facebook'] ); ?>" class="socials__link" target="_blank">
                                                        <i class="fa-brands fa-facebook-f"></i>
                                                    </a>
                                                </li>
                                            <?php endif; ?>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
            </div>
        </div>
        <?php if ( ! empty( $custom_options_theme['additional_info_copy'] ) ): ?>
        <div class="footer__copy">
            <div class="grid-container">
                <div class="grid-x grid-padding-x">
                    <div class="cell">
                        <div class="footer__wrap">
                            <p class="footer__copy-text"><?php echo esc_html( $custom_options_theme['additional_info_copy'] ); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </footer>

    <!-- Pop-up -->
    <?php
    $show_info_section = ! empty( $custom_options_theme['additional_info_popup'] ) ||
                        ! empty( $custom_options_theme['title_for_contacts'] ) ||
                        ! empty( $custom_options_theme['phone_1'] ) ||
                        ! empty( $custom_options_theme['phone_2'] ) ||
                        ( ! empty( $custom_options_theme['address_name'] ) && ! empty( $custom_options_theme['address_link'] ) ) ||
                        ! empty( $custom_options_theme['work_hours_title'] ) ||
                        ! empty( $custom_options_theme['work_hours_weekdays'] ) ||
                        ! empty( $custom_options_theme['work_hours_weekends'] );
    ?>

    <?php if ( $show_info_section ): ?>
        <div class="info">
            <div class="info__btn-close"></div>
            <div class="info__wrapper">
                <?php if ( ! empty( $custom_options_theme['additional_info_popup'] ) ): ?>
                    <p class="info__text"><?php echo esc_html( $custom_options_theme['additional_info_popup'] ); ?></p>
                <?php endif; ?>
                
                <div class="info__wrap">
                    <?php if ( ! empty( $custom_options_theme['title_for_contacts'] ) ): ?>
                        <h4 class="info__title"><?php echo esc_html( $custom_options_theme['title_for_contacts'] ); ?></h4>
                    <?php endif; ?>
                    <ul class="info__items">
                        <?php if ( ! empty( $custom_options_theme['phone_1'] ) ): ?>
                            <li class="info__item">
                                <a href="tel:+<?php echo preg_replace( '/[^\d]/', '', $custom_options_theme['phone_1'] ); ?>" class="info__link">
                                    <?php echo $custom_options_theme['phone_1']; ?>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if ( ! empty( $custom_options_theme['phone_2'] ) ): ?>
                            <li class="info__item">
                                <a href="tel:+<?php echo preg_replace( '/[^\d]/', '', $custom_options_theme['phone_2'] ); ?>" class="info__link">
                                    <?php echo $custom_options_theme['phone_2']; ?>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if ( ! empty( $custom_options_theme['address_name'] ) && ! empty( $custom_options_theme['address_link'] ) ): ?>
                            <li class="info__item">
                                <a href="<?php echo esc_url( $custom_options_theme['address_link'] ); ?>" class="info__link" target="_blank">
                                    <?php echo esc_html( $custom_options_theme['address_name'] ); ?>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="info__wrap info__wrap-2">
                    <?php if ( ! empty( $custom_options_theme['work_hours_title'] ) ): ?>
                        <h4 class="info__title"><?php echo esc_html( $custom_options_theme['work_hours_title'] ); ?></h4>
                    <?php endif; ?>
                    <ul class="info__items">
                        <?php if ( ! empty( $custom_options_theme['work_hours_weekdays'] ) ): ?>
                            <li class="info__item">
                                <p class="info__nolink"><?php echo esc_html( $custom_options_theme['work_hours_weekdays'] ); ?></p>
                            </li>
                        <?php endif; ?>
                        <?php if ( ! empty( $custom_options_theme['work_hours_weekends'] ) ): ?>
                            <li class="info__item">
                                <p class="info__nolink"><?php echo esc_html( $custom_options_theme['work_hours_weekends'] ); ?></p>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Pop-up -->
    <div id="popup" class="popup" style="display:none;">
        <div class="popup__container">
            <div class="popup__wrapper">
                <span class="popup__close">×</span>
                <div class="popup__content">
                    <h3 class="popup__title"><?php echo __('Contact us now', 'custom-theme'); ?></h3>
                    <p class="popup__info"><?php echo __('Our manager will contact you as soon as possible.', 'custom-theme'); ?></p>
                </div>
                <div class="popup__form">
                    <form action="<?php echo esc_url( home_url( '/wp-content/themes/custom-theme/process_form.php' ) ); ?>" method="post" class="form">
                        <input type="text" id="name-2" name="name" placeholder="Name" required autocomplete="off" class="form__input">
                        <input type="tel" id="phone-2" name="phone" required placeholder="Phone Number" autocomplete="off" class="form__input phone">
                        <div class="form__btn btn">
                            <button type="submit" class="btn__wrap"><?php echo __('Subscribe', 'custom-theme'); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Phones -->
    <?php
    $show_phones_section = ! empty( $custom_options_theme['phone_1'] ) ||
                        ! empty( $custom_options_theme['phone_2'] ) ||
                        ! empty( $custom_options_theme['instagram'] ) ||
                        ! empty( $custom_options_theme['tiktok'] ) ||
                        ! empty( $custom_options_theme['facebook'] ) ||
                        ! empty( $custom_options_theme['icon_4'] );
    ?>

    <?php if ( $show_phones_section ): ?>
        <div class="phones">
            <?php if ( ! empty( $custom_options_theme['icon_4'] ) ): ?>
                <?php
                $icon_4_url = $custom_options_theme['icon_4'];
                $icon_4_id = attachment_url_to_postid( $icon_4_url );
                $icon_4_alt = get_post_meta( $icon_4_id, '_wp_attachment_image_alt', true );

                if ( empty( $icon_4_alt ) ) {
                    $icon_4_alt = get_bloginfo( 'name' );
                }
                ?>
                <div class="phones__icon">
                    <img src="<?php echo esc_url( $icon_4_url ); ?>" alt="<?php echo esc_attr( $icon_4_alt ); ?>">
                </div>
            <?php endif; ?>
            <div class="phones__wrap">
                <?php if ( ! empty( $custom_options_theme['phone_1'] ) ): ?>
                    <a href="tel:+<?php echo preg_replace( '/[^\d]/', '', $custom_options_theme['phone_1'] ); ?>" class="phones__link">
                        <?php echo esc_html( $custom_options_theme['phone_1'] ); ?>
                    </a>
                <?php endif; ?>
                <?php if ( ! empty( $custom_options_theme['phone_2'] ) ): ?>
                    <a href="tel:+<?php echo preg_replace( '/[^\d]/', '', $custom_options_theme['phone_2'] ); ?>" class="phones__link">
                        <?php echo esc_html( $custom_options_theme['phone_2'] ); ?>
                    </a>
                <?php endif; ?>
            </div>
            <?php if ( ! empty( $custom_options_theme['instagram'] ) || ! empty( $custom_options_theme['tiktok'] ) || ! empty( $custom_options_theme['facebook'] ) ): ?>
                <ul class="socials phones__socials">
                    <?php if ( ! empty( $custom_options_theme['instagram'] ) ): ?>
                        <li class="socials__item">
                            <a href="<?php echo esc_url( $custom_options_theme['instagram'] ); ?>" class="socials__link" target="_blank">
                                <i class="fa-brands fa-instagram"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if ( ! empty( $custom_options_theme['tiktok'] ) ): ?>
                        <li class="socials__item">
                            <a href="<?php echo esc_url( $custom_options_theme['tiktok'] ); ?>" class="socials__link" target="_blank">
                                <i class="fa-brands fa-tiktok"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if ( ! empty( $custom_options_theme['facebook'] ) ): ?>
                        <li class="socials__item">
                            <a href="<?php echo esc_url( $custom_options_theme['facebook'] ); ?>" class="socials__link" target="_blank">
                                <i class="fa-brands fa-facebook-f"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <!-- Scroll up btn -->
    <?php if ( ! empty( $custom_options_theme ) && ! empty( $custom_options_theme['icon_3'] ) ): ?>
    <?php
        $icon_3_url = $custom_options_theme['icon_3'];
        $icon_3_id = attachment_url_to_postid( $icon_3_url );
        $icon_3_alt = get_post_meta( $icon_3_id, '_wp_attachment_image_alt', true );

        if ( empty( $icon_3_alt ) ) {
            $icon_3_alt = get_bloginfo( 'name' );
        }
        ?>
        <div class="scroll-up">
            <div class="scroll-up__icon">
                <img src="<?php echo esc_url( $icon_3_url ); ?>" alt="<?php echo esc_attr( $icon_3_alt ); ?>">
            </div>
        </div>
    <?php endif; ?>

    <?php wp_footer(); ?>

</body>

</html>