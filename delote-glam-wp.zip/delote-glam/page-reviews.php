<?php
/*
Template Name: Page Reviews
*/
get_header();
?>

<main class="main-wrapper main-top">
    <section class="reviews section-top">
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell">
                    <div class="title">
                        <h1 class="title__wrap"><?php the_title(); ?></h1>
                    </div>
                </div>
            </div>
        </div>
        <div class="reviews__container grid-container">
        <?php if (comments_open() || get_comments_number()) : ?>
            <?php comments_template( '/comments.php' ); ?>
        <?php endif; ?>
        </div>
    </section>
</main>

<?php
    // Output the page content
    the_content();
?>

<?php get_footer(); ?>