<?php
/*
Template Name: Page Services
*/
get_header();
?>

<main class="main-wrapper main-top">
    <section class="prices section-top">
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell">
                    <div class="title">
                        <h1 class="title__wrap"><?php the_title(); ?></h1>
                    </div>
                </div>
            </div>
        </div>
        <?php
            $services = carbon_get_post_meta(get_the_ID(), 'services_repeater');

            if ($services): ?>
        <div class="prices__container grid-container">
            <div class="grid-x grid-padding-x">
                <?php foreach ($services as $service): ?>
                <?php if (!empty($service['services_item_image'])): ?>
                <div class="cell small-12 medium-6 large-6">
                    <div class="prices__img">
                        <img src="<?php echo wp_get_attachment_image_url($service['services_item_image'], 'full'); ?>"
                            alt="<?php echo !empty($service['services_details'][0]['services_detail_name']) ? esc_attr($service['services_details'][0]['services_detail_name']) : ''; ?>">
                    </div>
                </div>
                <?php endif; ?>
                <div class="cell small-12 medium-6 large-6">
                    <div class="prices__wrap">
                        <div class="prices__info">
                            <?php foreach ($service['services_details'] as $detail): ?>
                            <div class="prices__info-wrap">
                                <div class="prices__name">
                                    <?php if (!empty($detail['services_detail_name'])): ?>
                                    <h3><?php echo esc_html($detail['services_detail_name']); ?></h3>
                                    <?php endif; ?>
                                    <?php if (!empty($detail['services_detail_description'])): ?>
                                    <p><?php echo esc_html($detail['services_detail_description']); ?></p>
                                    <?php endif; ?>
                                </div>
                                <?php if (!empty($detail['services_detail_price'])): ?>
                                <div class="prices__price">
                                    <?php echo esc_html($detail['services_detail_price']); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </section>
</main>

<?php
    // Output the page content
    the_content();
?>

<?php get_footer(); ?>