<?php
// Register type of record for the slider
add_action( 'init', function () {
    register_post_type( 'slider', array(
        'labels'       => array(
            'name'          => __( 'Slider', 'default' ),
            'singular_name' => __( 'Slider', 'default' ),
            'add_new'       => __( 'Add new slide', 'default' ),
            'add_new_item'  => __( 'New slide', 'default' ),
            'edit_item'     => __( 'Edit', 'default' ),
            'new_item'      => __( 'New slide', 'default' ),
            'view_item'     => __( 'View', 'default' ),
            'menu_name'     => __( 'Slider', 'default' ),
            'all_items'     => __( 'All slides', 'default' ),
        ),
        'public'       => true,
        'supports'     => array( 'title', 'editor', 'thumbnail' ),
        'menu_icon'    => 'dashicons-format-gallery',
        'show_in_rest' => true,
    ) );
} );

add_action( 'save_post_slider', 'save_slider_meta_box' );
function custom_display_slider() {
    $args = array(
        'post_type'      => 'slider',
        'posts_per_page' => -1, 
        'order' => 'DESC',
    );

    $slider_query = new WP_Query( $args );

    if ( $slider_query->have_posts() ) {
        ?>
        <section class="home-slider">
            <div class="home-slider__slick">
        <?php
            while ( $slider_query->have_posts() ) : $slider_query->the_post();
            // Getting value from meta fields for buttons created for Home Slider
                $thumbnail_id = get_post_thumbnail_id();
                $slide_content = get_the_content();
                $related_post_1 = get_post_meta( get_the_ID(), '_slider_related_post_1', true );
                $open_in_new_tab_1 = get_post_meta( get_the_ID(), '_slider_open_in_new_tab_1', true );
                $button_text_1 = get_post_meta( get_the_ID(), '_slider_button_text_1', true );
                $external_url_1 = get_post_meta( get_the_ID(), '_slider_external_url_1', true );
                $button_type_1 = get_post_meta( get_the_ID(), '_slider_button_type_1', true );
                $related_post_2 = get_post_meta( get_the_ID(), '_slider_related_post_2', true );
                $open_in_new_tab_2 = get_post_meta( get_the_ID(), '_slider_open_in_new_tab_2', true );
                $button_text_2 = get_post_meta( get_the_ID(), '_slider_button_text_2', true );
                $external_url_2 = get_post_meta( get_the_ID(), '_slider_external_url_2', true );
                $button_type_2 = get_post_meta( get_the_ID(), '_slider_button_type_2', true );
            ?>
                <div class="home-slider__wrap">
                    <?php if ( $thumbnail_id ) { ?>
                        <div class="home-slider__img">
                            <img src="<?php echo esc_url( wp_get_attachment_url( $thumbnail_id ) ); ?>" alt="<?php the_title(); ?>">
                        </div>
                    <?php } ?>
                    <div class="home-slider__container grid-container">
                        <div class="grid-x grid-padding-x">
                            <div class="cell">
                                <div class="home-slider__item">
                                    <h2 class="home-slider__title"><?php the_title(); ?></h2>

                                    <?php if ( !empty($slide_content) ) : ?>
                                        <div class="home-slider__info">
                                            <?php the_content(); ?>
                                        </div>
                                    <?php endif; ?>

                                    <?php if ( $related_post_1 || $external_url_1 || $related_post_2 || $external_url_2 ): ?>
                                        <div class="home-slider__btns">
                                            <?php if ( ($related_post_1 && $related_post_1 !== 'none') || $external_url_1 ): ?>
                                                <?php
                                                    if ( $button_type_1 === 'external' && empty($external_url_1) ) {
                                                        $related_post_url_1 = ''; 
                                                    } elseif ( $button_type_1 === 'external' && !empty($external_url_1) ) {
                                                        $related_post_url_1 = $external_url_1;
                                                    } elseif ( $related_post_1 && $related_post_1 !== 'none' ) {
                                                        $related_post_url_1 = get_permalink( $related_post_1 );
                                                    } else {
                                                        $related_post_url_1 = '';
                                                    }

                                                    $target_1 = ( $open_in_new_tab_1 === 'on' ) ? ' target="_blank"' : '';
                                                    $button_text_1 = !empty($button_text_1) ? $button_text_1 : __('Read more', 'default');
                                                ?>
                                                <?php if ( !empty($related_post_url_1) ): ?>
                                                    <div class="home-slider__btn btn btn-5">
                                                        <a href="<?php echo esc_url( $related_post_url_1 ); ?>" class="btn__wrap btn-4__wrap"<?php echo $target_1; ?>>
                                                            <?php echo esc_html( $button_text_1 ); ?>
                                                        </a>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>

                                            <?php if ( ($related_post_2 && $related_post_2 !== 'none') || $external_url_2 ): ?>
                                                <?php
                                                    if ( $button_type_2 === 'external' && empty($external_url_2) ) {
                                                        $related_post_url_2 = ''; 
                                                    } elseif ( $button_type_2 === 'external' && !empty($external_url_2) ) {
                                                        $related_post_url_2 = $external_url_2;
                                                    } elseif ( $related_post_2 && $related_post_2 !== 'none' ) {
                                                        $related_post_url_2 = get_permalink( $related_post_2 );
                                                    } else {
                                                        $related_post_url_2 = '';
                                                    }

                                                    $target_2 = ( $open_in_new_tab_2 === 'on' ) ? ' target="_blank"' : '';
                                                    $button_text_2 = !empty($button_text_2) ? $button_text_2 : __('Read more', 'default');
                                                ?>
                                                <?php if ( !empty($related_post_url_2) ): ?>
                                                    <div class="home-slider__btn btn btn-5">
                                                        <a href="<?php echo esc_url( $related_post_url_2 ); ?>" class="btn__wrap btn-3__wrap"<?php echo $target_2; ?>>
                                                            <?php echo esc_html( $button_text_2 ); ?>
                                                        </a>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                    <!-- // Add custom options in customizer -->
                                    <?php $custom_options_theme = custom_options_theme(); ?>
                                    
                                    <?php if ( ! empty( $custom_options_theme['icon_5'] ) ): ?>
                                        <?php
                                        $icon_5_url = $custom_options_theme['icon_5'];
                                        $icon_5_id = attachment_url_to_postid( $icon_5_url );
                                        $icon_5_alt = get_post_meta( $icon_5_id, '_wp_attachment_image_alt', true );

                                        if ( empty( $icon_5_alt ) ) {
                                            $icon_5_alt = get_bloginfo( 'name' );
                                        }
                                        ?>
                                    <div class="scrooll-down">
                                        <a href="#about" class="scrooll-down__wrap">
                                            <img src="<?php echo esc_url( $icon_5_url ); ?>" alt="<?php echo esc_attr( $icon_5_alt ); ?>">
                                            <?php echo esc_attr( $icon_5_alt ); ?>
                                        </a>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
            </div>
        </section>
        <?php
        wp_reset_postdata();
    } else {
        echo '<p>' . __( 'No slides found.', 'custom' ) . '</p>';
    }
}
?>
