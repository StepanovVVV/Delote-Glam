<?php
/*
Template Name: Page Posts
*/
get_header();
?>

<section class="block section-top">
    <div class="grid-container">
        <div class="grid-x grid-padding-x">
            <div class="cell">
                <div class="title">
                    <h1 class="title__wrap"><?php the_title(); ?></h1>
                </div>
            </div>
        </div>
    </div>

    <div class="block__container grid-container">
        <?php
        $post_types = carbon_get_post_meta(get_the_ID(), 'truemisha_post_type'); 
        $categories = carbon_get_post_meta(get_the_ID(), 'truemisha_page_num'); 
        $posts_per_page = carbon_get_post_meta(get_the_ID(), 'truemisha_post_count') ?: 6;
        $post_type = $post_types ? $post_types[0] : 'post'; 
        $all_posts = wp_count_posts($post_type)->publish; 
        ?>

        <div class="grid-x grid-padding-x" id="post-grid" data-total-posts="<?php echo $all_posts; ?>">
        
            <?php
            $args = array(
                'post_type' => $post_type, 
                'posts_per_page' => $posts_per_page,    
                'orderby' => 'date',                     
                'order' => 'ASC',                        
                'category__in' => $categories,           
            );

            $posts_query = new WP_Query($args);

            if ($posts_query->have_posts()) :
                while ($posts_query->have_posts()) : $posts_query->the_post();
                    ?>
                    <div class="cell small-12 medium-6 large-4" data-post-id="<?php echo get_the_ID(); ?>">
                        <div class="block__wrap">
                            <div class="frame">
                                <div class="block__img">
                                    <?php
                                        if (has_post_thumbnail()) {
                                            echo get_the_post_thumbnail(get_the_ID(), 'medium');
                                        } else {
                                            echo '<img src="' . esc_url(get_template_directory_uri()) . '/assets/image/default-image.jpg" alt="Default Image">';
                                        }
                                    ?>
                                </div>
                            </div>
                            <?php if (get_the_title() || get_the_content()) : ?>
                                <div class="block__info">
                                    <?php if (get_the_title()) : ?>
                                        <h3 class="block__title"><?php the_title(); ?></h3>
                                    <?php endif; ?>
                                    <?php if (get_the_content()) : ?>
                                        <div class="block__text"><?php the_content(); ?></div>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endwhile;
                    wp_reset_postdata();
                else :
                    echo "<p>" . __('No posts found.', 'testdomain') . "</p>";
                endif;
            ?>
        </div>

        <?php
        if ($all_posts > $posts_per_page) :
        ?>
        <div class="btn block__btn">
            <button id="load-more-posts" class="btn__wrap load-more-btn"><?php echo __('Load More', 'testdomain'); ?></button>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php the_content(); ?>

<?php get_footer(); ?>
