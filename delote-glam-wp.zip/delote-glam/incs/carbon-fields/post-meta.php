<?php

if (!defined('ABSPATH')) {
    exit;
}

use Carbon_Fields\Container;
use Carbon_Fields\Field;

Container::make('post_meta', __('Additional fields'))
    ->where('post_id', '=', 39)
    ->add_tab(__('About us'), array(
        Field::make('text', 'about_section_title', __('Title section')), 
        Field::make('image', 'about_section_image', __('Section Image'))
            ->set_width(10), 
        Field::make('rich_text', 'about_section_content', __('Content'))
            ->set_width(70),  
        Field::make('text', 'about_section_btn_more', __('Button name more'))
            ->set_width(10),  
        Field::make('text', 'about_section_btn_less', __('Button name less'))
            ->set_width(10)  
    ))
    ->add_tab(__('Comfort'), array(
        Field::make('complex', 'comfort_repeater', __('Comfort Items'))
            ->setup_labels(array(
                'plural_name' => "items",
                'singular_name' => "item", 
            ))
            ->set_collapsed(true)
            ->add_fields(array(
                Field::make('image', 'comfort_item_image', __('Image'))
                    ->set_width(50) 
                    ->set_help_text(__('Upload an image for the comfort item')),
                
                Field::make('textarea', 'comfort_item_text', __('Text'))
                    ->set_width(50) 
                    ->set_help_text(__('Enter text for the comfort item')),
            ))
    ))
    ->add_tab(__('Our services'), array(
        Field::make('text', 'our_services_title', __('Title section'))
            ->set_help_text(__('Enter the title for the services section')), 
        Field::make('complex', 'our_services_repeater', __('Our services'))
            ->setup_labels(array(
                'plural_name' => "services",
                'singular_name' => "service",
            ))
            ->set_collapsed(true)
            ->add_fields(array(
                Field::make('image', 'our_services_image', __('Image'))
                    ->set_width(50)
                    ->set_help_text(__('Upload an image for the service')),
                
                Field::make('textarea', 'our_services_text', __('Text'))
                    ->set_width(50)
                    ->set_help_text(__('Enter text for the service')),
            ))
    ))
    ->add_tab(__('Brands'), array(
        Field::make('complex', 'brands_repeater', __('Brand Items'))
            ->setup_labels(array(
                'plural_name' => "brands",
                'singular_name' => "brand", 
            ))
            ->set_collapsed(true)
            ->add_fields(array(
                Field::make('image', 'brands_item_image', __('Image'))
                    ->set_help_text(__('Upload an image for the brands item')),
            ))
    ))
    ->add_tab(__('Our accomplishments'), array(
        Field::make('text', 'our_accomplishments_title', __('Title'))
            ->set_help_text(__('Enter the title for the accomplishments section')),
        Field::make('image', 'our_accomplishments_image', __('Image'))
            ->set_width(20) 
            ->set_help_text(__('Upload an image for the accomplishments section')),
        Field::make('rich_text', 'our_accomplishments_content', __('Content'))
            ->set_width(70) 
            ->set_help_text(__('Add content for the accomplishments section')),
        Field::make('text', 'our_accomplishments_button_name', __('Button name'))
            ->set_help_text(__('Enter the URL for the button "Make an appointment"'))
            ->set_width(10), 
    ))
    ->add_tab(__('Our works'), array(
        Field::make('text', 'our_works_title', __('Title'))
        ->set_help_text(__('Enter the title for the our works section')),
        Field::make('complex', 'media_gallery', __('Media Gallery'))
            ->set_help_text(__('Add images to your gallery'))
            ->set_collapsed(true)
            ->setup_labels(array(
                'plural_name' => "images",
                'singular_name' => "image", 
            ))
            ->add_fields(array(
                Field::make('image', 'gallery_image', __('Image'))
                    ->set_help_text(__('Upload an image for the gallery')),
            ))
    ));

Container::make('post_meta', __('Stock Items'))
    ->where('post_id', '=', 279) 
    ->add_tab(__('Stock'), array(
        Field::make('complex', 'stock_repeater', __('Stock Items'))
            ->setup_labels(array(
                'plural_name'   => "Stock Items",
                'singular_name' => "Stock Item", 
            ))
            ->set_collapsed(true)
            ->add_fields(array(
                Field::make('image', 'stock_item_image', __('Stock Image'))
                    ->set_help_text(__('Upload an image for the stock item'))
                    ->set_width(20),
                Field::make('complex', 'stock_details', __('Stock Details'))
                    ->set_width(70)
                    ->setup_labels(array(
                        'plural_name'   => "Stock Details",
                        'singular_name' => "Stock Detail",
                    ))
                    ->set_collapsed(true)
                    ->add_fields(array(
                        Field::make('text', 'stock_detail_name', __('Stock Name'))
                            ->set_help_text(__('Enter stock name'))
                            ->set_width(30),
                        Field::make('text', 'stock_detail_description', __('Stock Description'))
                            ->set_help_text(__('Enter stock description'))
                            ->set_width(40),
                        Field::make('text', 'stock_detail_sale', __('Stock % sale'))
                            ->set_help_text(__('Enter stock % sale'))
                            ->set_width(30),
                    )),
                Field::make('checkbox', 'stock_reverse', __('Reverse this item?'))
                    ->set_width(10)
                    ->set_option_value('yes')
                    ->set_help_text(__('Check to add a special class'))
            ))
    ));

$custom_options_theme = custom_options_theme();
$page_ids_string = $custom_options_theme['page_ids'];
$page_ids = explode(',', $page_ids_string);

Container::make( 'post_meta', 'Output posts for template Page Posts' )
    ->where( 'post_id', 'IN', $page_ids )
    ->add_fields( array(
        Field::make( 'multiselect', 'truemisha_post_type', 'Select post types' )
            ->add_options( function() {
                $post_types = get_post_types( array( 'public' => true ), 'objects' );
                $options = array();
                foreach ( $post_types as $post_type ) {
                    $options[ $post_type->name ] = $post_type->label; 
                }
                return $options;
            } ),
        Field::make( 'multiselect', 'truemisha_page_num', 'Select categories' )
            ->add_options( function() {
                $categories = get_terms( array(
                    'taxonomy'   => 'category',
                    'hide_empty' => false, 
                ) );
                $options = array();
                if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) {
                    foreach ( $categories as $category ) {
                        $options[ $category->term_id ] = $category->name;
                    }
                }
                return $options;
            } ),
        Field::make( 'text', 'truemisha_post_count', __( 'Number of posts to display' ) ),
    ) );

Container::make('post_meta', __('Services (Carbon Fields)'))
    ->where('post_id', '=', 333) 
    ->or_where('post_id', '=', 329) 
    ->or_where('post_id', '=', 327)
    ->or_where('post_id', '=', 335)
    ->or_where('post_id', '=', 331)
    ->add_tab(__('Stock'), array(
        Field::make('complex', 'services_repeater', __('Services Items'))
            ->setup_labels(array(
                'plural_name'   => "Services Items",
                'singular_name' => "Services Item", 
            ))
            ->set_collapsed(true)
            ->add_fields(array(
                Field::make('image', 'services_item_image', __('Service Image'))
                    ->set_help_text(__('Upload an image for the service item'))
                    ->set_width(20),
                Field::make('complex', 'services_details', __('Service Details'))
                    ->set_width(70)
                    ->setup_labels(array(
                        'plural_name'   => "Services Details",
                        'singular_name' => "Services Detail",
                    ))
                    ->set_collapsed(true)
                    ->add_fields(array(
                        Field::make('text', 'services_detail_name', __('Service Name'))
                            ->set_help_text(__('Enter service name'))
                            ->set_width(30),
                        Field::make('text', 'services_detail_description', __('Service Description'))
                            ->set_help_text(__('Enter service description'))
                            ->set_width(40),
                        Field::make('text', 'services_detail_price', __('Service price'))
                            ->set_help_text(__('Enter service price'))
                            ->set_width(30),
                    )),
            ))
    ));

