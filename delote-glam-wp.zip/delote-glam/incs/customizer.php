<?php
add_action( 'customize_register', function ( WP_Customize_Manager $wp_customize ) {

    // Section for custom settings
    $wp_customize->add_section( 'custom_options_theme', array(
        'title'    => __( 'Contacts', 'default' ),
        'priority' => 10,
    ) );

    // Title for contacts
    $wp_customize->add_setting( 'title_for_contacts', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field', // Validation
    ) );
    $wp_customize->add_control( 'title_for_contacts', array(
        'label'   => __( 'Title for contacts', 'default' ),
        'section' => 'custom_options_theme',
    ) );

    // Phone 1
    $wp_customize->add_setting( 'custom_phone_1', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'custom_phone_1', array(
        'label'   => __( 'Phone 1', 'default' ),
        'section' => 'custom_options_theme',
    ) );

    // Phone 2
    $wp_customize->add_setting( 'custom_phone_2', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'custom_phone_2', array(
        'label'   => __( 'Phone 2', 'default' ),
        'section' => 'custom_options_theme',
    ) );

    // Address
    $wp_customize->add_setting( 'custom_address', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'custom_address', array(
        'label'   => __( 'Address name', 'default' ),
        'section' => 'custom_options_theme',
    ) );

    // Address link
    $wp_customize->add_setting( 'custom_address_link', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw', // Validation for URL
    ) );
    $wp_customize->add_control( 'custom_address_link', array(
        'label'   => __( 'Address link', 'default' ),
        'section' => 'custom_options_theme',
    ) );

    // Google Maps API Key
    $wp_customize->add_section('google_maps_section', array(
        'title' => __('Google Maps API', 'default'),
        'priority' => 30,
    ));

    $wp_customize->add_setting('google_maps_api_key', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field', // Validate API key
    ));

    $wp_customize->add_control('google_maps_api_key', array(
        'label' => __('Google Maps API Key', 'default'),
        'section' => 'google_maps_section',
        'type' => 'text',
    ));

    // Title for social media
    $wp_customize->add_setting( 'title_for_social_media', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'title_for_social_media', array(
        'label'   => __( 'Title for social media', 'default' ),
        'section' => 'custom_options_theme',
    ) );

    // Social media links
    $social_media_settings = [
        'custom_instagram' => __( 'Instagram Link', 'default' ),
        'custom_tiktok' => __( 'TikTok Link', 'default' ),
        'custom_facebook' => __( 'Facebook Link', 'default' ),
    ];
    
    foreach ( $social_media_settings as $setting_key => $label ) {
        $wp_customize->add_setting( $setting_key, array(
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw', // Validation for URL
        ) );
        $wp_customize->add_control( $setting_key, array(
            'label'   => $label,
            'section' => 'custom_options_theme',
        ) );
    }

    // Section for icons
    $wp_customize->add_section( 'custom_icon_section', array(
        'title'    => __( 'Additional Icons', 'default' ),
        'priority' => 20,
    ) );

    // Icons
    $icon_settings = [
        'custom_icon_1' => __( 'Icon open 1', 'default' ),
        'custom_icon_2' => __( 'Icon open 2', 'default' ),
        'custom_icon_3' => __( 'Scroll up', 'default' ),
        'custom_icon_4' => __( 'Phone', 'default' ),
        'custom_icon_5' => __( 'Scroll down', 'default' ),
    ];

    foreach ( $icon_settings as $setting_key => $label ) {
        $wp_customize->add_setting( $setting_key, array(
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw', // Validation for URL
        ) );
        $wp_customize->add_control( new WP_Customize_Image_Control(
            $wp_customize, $setting_key, array(
                'label'    => $label,
                'section'  => 'custom_icon_section',
                'settings' => $setting_key,
            )
        ) );
    }

    // Section for work hours
    $wp_customize->add_section( 'work_hours_section', array(
        'title'    => __( 'Work Hours', 'default' ),
        'priority' => 30,
    ) );

    // Title for work hours
    $wp_customize->add_setting( 'work_hours_title', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field', // Validation
    ) );
    $wp_customize->add_control( 'work_hours_title', array(
        'label'   => __( 'Work Hours Title', 'default' ),
        'section' => 'work_hours_section',
    ) );

    // Work hours for weekdays
    $wp_customize->add_setting( 'work_hours_weekdays', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'work_hours_weekdays', array(
        'label'   => __( 'Work hours for weekdays', 'default' ),
        'section' => 'work_hours_section',
    ) );

    // Work hours for weekends
    $wp_customize->add_setting( 'work_hours_weekends', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'work_hours_weekends', array(
        'label'   => __( 'Work hours for weekends', 'default' ),
        'section' => 'work_hours_section',
    ) );

    // New Section for the additional text field
    $wp_customize->add_section( 'additional_text_section', array(
        'title'    => __( 'Additional Information', 'default' ),
        'priority' => 40,
    ) );

    // Large Text Area for additional information
    $wp_customize->add_setting( 'additional_info_popup', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_textarea_field', // Validation for textarea
    ) );
    $wp_customize->add_control( 'additional_info_popup', array(
        'label'   => __( 'Additional Information for Pop-up', 'default' ),
        'section' => 'additional_text_section',
        'type'    => 'textarea', // Make it a large text field
    ) );

    //  For additional information Copy
    $wp_customize->add_setting( 'additional_info_copy', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_textarea_field', // Validation for textarea
    ) );
    $wp_customize->add_control( 'additional_info_copy', array(
        'label'   => __( 'Copyright', 'default' ),
        'section' => 'additional_text_section',
        'type'    => 'textarea', // Make it a large text field
    ) );

    $wp_customize->add_section( 'custom_page_ids_section', array(
        'title'    => __( 'Page IDs for posts using Carbon Fields', 'default' ),
        'priority' => 50,
    ) );

    $wp_customize->add_setting( 'custom_page_ids', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field', // Очистка ввода
    ) );

    $wp_customize->add_control( 'custom_page_ids', array(
        'label'   => __( 'Enter Page IDs (separated by commas)', 'default' ),
        'section' => 'custom_page_ids_section',
        'type'    => 'text', // Тип поля: текстовое
    ) );
}, 10 );

// Get settings as an array
function custom_options_theme() {
    return array(
        'title_for_contacts'       => get_theme_mod( 'title_for_contacts', '' ),
        'phone_1'                   => get_theme_mod( 'custom_phone_1', '' ),
        'phone_2'                   => get_theme_mod( 'custom_phone_2', '' ),
        'address_name'              => get_theme_mod( 'custom_address', '' ),
        'address_link'              => get_theme_mod( 'custom_address_link', '' ),
        'google_maps_api_key'      => get_theme_mod( 'google_maps_api_key', '' ),
        'title_for_social_media'   => get_theme_mod( 'title_for_social_media', '' ),
        'instagram'                 => get_theme_mod( 'custom_instagram', '' ),
        'tiktok'                    => get_theme_mod( 'custom_tiktok', '' ),
        'facebook'                  => get_theme_mod( 'custom_facebook', '' ),
        // Section icons
        'icon_1'                    => get_theme_mod( 'custom_icon_1', '' ),
        'icon_2'                    => get_theme_mod( 'custom_icon_2', '' ),
        'icon_3'                    => get_theme_mod( 'custom_icon_3', '' ),
        'icon_4'                    => get_theme_mod( 'custom_icon_4', '' ),
        'icon_5'                    => get_theme_mod( 'custom_icon_5', '' ),
        // Section work hours
        'work_hours_title'          => get_theme_mod( 'work_hours_title', '' ),
        'work_hours_weekdays'       => get_theme_mod( 'work_hours_weekdays', '' ),
        'work_hours_weekends'       => get_theme_mod( 'work_hours_weekends', '' ),
        // Section additional information
        'additional_info_popup'      => get_theme_mod( 'additional_info_popup', '' ),
        'additional_info_copy'     => get_theme_mod( 'additional_info_copy', '' ),
        // Add getting value for page_ids
        'page_ids'                  => get_theme_mod( 'custom_page_ids', '' ),
    );
}

// using code in layout
/* 
    // Add function on page 
    <?php $custom_options_theme = custom_options_theme(); ?>

    <?php if ( ! empty( $custom_options_theme['phone'] ) ): ?>
        <a href="tel:+<?php echo preg_replace( '/[^\d]/', '', $custom_options_theme['phone'] ); ?>">
            <?php echo $custom_options_theme['phone']; ?>
        </a>
    <?php endif; ?>

    <?php if ( ! empty( $custom_options_theme['facebook'] ) ): ?>
        <li>
            <a href="<?php echo $custom_options_theme['facebook'] ?>"></a>
        </li>
    <?php endif; ?>
*/
?>

