<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo( 'charset' ) ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <?php wp_head(); ?>
</head>

<!-- // Add customizer -->
<?php $custom_options_theme = custom_options_theme(); ?>

<body <?php body_class(); ?> class="hidden body-wrapper" id="content">
    <?php wp_body_open(); ?>
    <header class="header">
        <div class="header__container grid-container">
            <div class="header__menu header__menu-desc">
                <?php if ( ! empty( $custom_options_theme['instagram'] ) || ! empty( $custom_options_theme['tiktok'] ) || ! empty( $custom_options_theme['facebook'] ) ): ?>
                    <ul class="socials">
                        <?php if ( ! empty( $custom_options_theme['instagram'] ) ): ?>
                        <li class="socials__item">
                            <a href="<?php echo esc_url( $custom_options_theme['instagram'] ); ?>" class="socials__link" target="_blank">
                                <i class="fa-brands fa-instagram"></i>
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <?php if ( ! empty( $custom_options_theme['tiktok'] ) ): ?>
                        <li class="socials__item">
                            <a href="<?php echo esc_url( $custom_options_theme['tiktok'] ); ?>" class="socials__link" target="_blank">
                                <i class="fa-brands fa-tiktok"></i>
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <?php if ( ! empty( $custom_options_theme['facebook'] ) ): ?>
                        <li class="socials__item">
                            <a href="<?php echo esc_url( $custom_options_theme['facebook'] ); ?>" class="socials__link" target="_blank">
                                <i class="fa-brands fa-facebook-f"></i>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                <?php endif; ?>
                <?php if ( has_nav_menu( 'header-menu-left' ) ): ?>
                <nav class="header__nav">
                    <?php 
                        wp_nav_menu(array(
                            'theme_location' => 'header-menu-left',
                            'container' => false,
                            'menu_class' => 'header__items',
                            'walker' => new Starter_Navigation(),
                        ));
                    ?>
                </nav>
                <?php endif; ?>
            </div>
            <div class="header__logo">
                <a href="<?php echo home_url( '/' ); ?>">
                    <?php
                    $custom_logo_id = get_theme_mod( 'custom_logo' );

                    if ( $custom_logo_id ) :
                        $logo_url = wp_get_attachment_image_src( $custom_logo_id, 'full' );

                        if ( $logo_url ) : ?>
                            <img src="<?php echo esc_url( $logo_url[0] ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" />
                        <?php endif; ?>
                    <?php else : ?>
                        <h1 class="header__title"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></h1>
                    <?php endif; ?>
                </a>
            </div>
            <div class="header__menu header__menu-desc">
            <?php if ( has_nav_menu( 'header-menu-right' ) ): ?>
                <nav class="header__nav">
                    <?php 
                        wp_nav_menu(array(
                            'theme_location' => 'header-menu-right',
                            'container' => false,
                            'menu_class' => 'header__items',
                            'walker' => new Starter_Navigation(),
                        ));
                    ?>
                </nav>
            <?php endif; ?>

            <?php if ( ! empty( $custom_options_theme['icon_1'] ) ): ?>
                <?php
                $icon_1_url = $custom_options_theme['icon_1'];
                $icon_1_id = attachment_url_to_postid( $icon_1_url );
                $icon_1_alt = get_post_meta( $icon_1_id, '_wp_attachment_image_alt', true );

                if ( empty( $icon_1_alt ) ) {
                    $icon_1_alt = get_bloginfo( 'name' );
                }
                ?>
                <div class="btn-open">
                    <a href="#!" class="btn-open__wrap">
                        <img src="<?php echo esc_url( $icon_1_url ); ?>" alt="<?php echo esc_attr( $icon_1_alt ); ?>" class="btn-open__icon">
                    </a>
                </div>
            <?php endif; ?>
            </div>
            <?php if ( ! empty( $custom_options_theme['icon_2'] ) ): ?>
                <?php
                $icon_2_url = $custom_options_theme['icon_2'];
                $icon_2_id = attachment_url_to_postid( $icon_2_url );
                $icon_2_alt = get_post_meta( $icon_2_id, '_wp_attachment_image_alt', true );

                if ( empty( $icon_2_alt ) ) {
                    $icon_2_alt = get_bloginfo( 'name' );
                }
                ?>
                <div class="btn-open btn-open__mob">
                    <a href="#!" class="btn-open__wrap">
                        <img src="<?php echo esc_url( $icon_2_url ); ?>" alt="<?php echo esc_attr( $icon_2_alt ); ?>" class="btn-open__icon">
                    </a>
                </div>
            <?php endif; ?>
            <div class="header__burger">
                <span></span>
            </div>
            <div class="header__menu header__menu-mob">
                <?php if ( has_nav_menu( 'header-menu' ) ): ?>
                <nav class="header__nav">
                    <?php 
                        wp_nav_menu(array(
                            'theme_location' => 'header-menu',
                            'container' => false,
                            'menu_class' => 'header__items',
                            'walker' => new Starter_Navigation(),
                        ));
                    ?>
                </nav>
                <?php endif; ?>
                <?php if ( ! empty( $custom_options_theme['instagram'] ) || ! empty( $custom_options_theme['tiktok'] ) || ! empty( $custom_options_theme['facebook'] ) ): ?>
                <ul class="header__socials socials">
                    <?php if ( ! empty( $custom_options_theme['instagram'] ) ): ?>
                    <li class="socials__item">
                        <a href="<?php echo esc_url( $custom_options_theme['instagram'] ); ?>" class="socials__link" target="_blank">
                            <i class="fa-brands fa-instagram"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php if ( ! empty( $custom_options_theme['tiktok'] ) ): ?>
                    <li class="socials__item">
                        <a href="<?php echo esc_url( $custom_options_theme['tiktok'] ); ?>" class="socials__link" target="_blank">
                            <i class="fa-brands fa-tiktok"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php if ( ! empty( $custom_options_theme['facebook'] ) ): ?>
                    <li class="socials__item">
                        <a href="<?php echo esc_url( $custom_options_theme['facebook'] ); ?>" class="socials__link" target="_blank">
                            <i class="fa-brands fa-facebook-f"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
                <?php endif; ?>
                <div class="header__overlay"></div>
            </div>
        </div>
    </header>