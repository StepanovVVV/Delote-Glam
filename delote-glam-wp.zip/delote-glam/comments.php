<?php
if ( post_password_required() ) {
    return;
}

$req = true;
$html_req = ( $req ? ' required="required"' : '' );
$html5 = true;
$consent = isset( $_COOKIE['wp-comment-cookies-consent'] ) ? ' checked="checked"' : '';
$post_id = get_the_ID();

$commenter = wp_get_current_commenter(); 
?>

<div id="comments" class="comments-area reviews__wrap">
    <?php
    $defaults = [
        'fields'               => [
            'author' => '<p class="comment-form-author reviews__form">
                <input autocomplete="name" id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30"' . $html_req . ' placeholder="' . esc_attr( __( 'Name' ) ) . '" />
            </p>',
            'email'  => '<p class="comment-form-email reviews__form">
                <input autocomplete="email" id="email" name="email" ' . ( $html5 ? 'type="email"' : 'type="text"' ) . ' value="' . esc_attr(  $commenter['comment_author_email'] ) . '" size="30" aria-describedby="email-notes"' . $html_req . ' placeholder="' . esc_attr( __( 'Email' ) ) . '" />
            </p>',
            
            'cookies' => '',
        ],
        'comment_field' => '<p class="comment-form-comment reviews__form"> 
            <textarea id="comment" name="comment" cols="45" rows="3" required="required" placeholder="' . esc_attr__( 'Write your review...' ) . '"></textarea>
            <div class="comment-form-rating rating reviews__rating">
                <span class="star" data-value="1">★</span>
                <span class="star" data-value="2">★</span>
                <span class="star" data-value="3">★</span>
                <span class="star" data-value="4">★</span>
                <span class="star" data-value="5">★</span>
            </div>
            <input type="hidden" name="rating" id="rating" value="0">
        </p>',
        'must_log_in'    => '',
        'logged_in_as'   => '',
        'comment_notes_before' => '',
        'comment_notes_after'  => '',
        'id_form'              => 'commentform',
        'id_submit'            => 'submit',
        'class_container'      => 'comment-respond',
        'class_form'           => 'comment-form',
        'class_submit'         => 'submit btn__wrap',
        'name_submit'          => 'submit',
        'title_reply'          => __( 'Feedback from our customers' ),
        'title_reply_to'       => __( 'Leave a Reply to %s' ),
        'title_reply_before'   => '<h3 id="reply-title" class="comment-reply-title reviews__title">',
        'title_reply_after'    => '</h3>',
        'cancel_reply_before'  => ' <small>',
        'cancel_reply_after'   => '</small>',
        'cancel_reply_link'    => __( 'Cancel reply' ),
        'label_submit'         => __( 'Submit Review' ),
        'submit_button'        => '<input name="%1$s" type="submit" id="%2$s" class="%3$s" value="%4$s" />',
        'submit_field'         => '<p class="form-submit comment-form-submit btn reviews__btn">%1$s %2$s</p>',
        'format'               => 'xhtml',
        'page'                 => 1, 
    ];
    
    comment_form( $defaults );
    ?>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const stars = document.querySelectorAll('.reviews__rating .star');
            const ratingInput = document.getElementById('rating');

            stars.forEach(star => {
                star.addEventListener('click', function () {
                    const value = this.getAttribute('data-value');
                    ratingInput.value = value;
                    stars.forEach(s => s.classList.remove(
                        'selected'));
                    for (let i = 0; i < value; i++) {
                        stars[i].classList.add('selected');
                    }
                });
            });
        });
    </script>

    <div class="reviews__list">
        <?php if ( have_comments() ) : ?>
        <h2 class="comments-title reviews__list-title">
            <?php
        echo esc_html__('Customer feedback', 'custom-theme');
    ?>
        </h2>

        <ol class="comment-list">
            <?php
                wp_list_comments(
                    array(
                        'walker' => new Start_Comment(),
                        'max_depth' => 2,
                        'style' => 'ol',
                        'type' => 'all',
                        'reply_text' => __('Ответить <i class="fa fa-reply"></i>'),
                        // 'per_page' => 8,
                        'avatar_size' => 80,
                        'format' => 'html5',
                        'echo' => true,
                        // 'orderby' => 'comment_date',
                        // 'order' => 'ASC',  
                    )
                );
            ?>
        </ol>


        <?php the_comments_navigation(); ?>

        <?php if ( ! comments_open() ) : ?>
        <p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'custom-theme' ); ?></p>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</div>