<?php
/*
Template Name: Front page
*/
$page_id = get_the_ID();
get_header(); ?>

<main class="main-wrapper main-top">

    <!-- Function to display home slider -->
    <?php custom_display_slider(); ?>
    <!-- Function to display home slider -->

    <?php 
        $about_section_title = carbon_get_post_meta($page_id, 'about_section_title');
        $image = carbon_get_post_meta($page_id, 'about_section_image');
        $about_section_content = carbon_get_post_meta($page_id, 'about_section_content');
        $read_more_text = carbon_get_post_meta($page_id, 'about_section_btn_more'); 
        $read_less_text = carbon_get_post_meta($page_id, 'about_section_btn_less'); 

        if ($about_section_title || $image || $about_section_content) : 
    ?>
    <section class="box" id="about">
        <?php if ($about_section_title): ?>
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell">
                    <div class="title">
                        <h2 class="title__wrap"><?php echo esc_html($about_section_title); ?></h2>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <div class="box__container grid-container">
            <div class="grid-x grid-padding-x">
                <?php if ($image) : 
                $image_url = wp_get_attachment_image_url($image, 'full');
                $image_alt = get_post_meta($image, '_wp_attachment_image_alt', true);
            ?>
                <div class="cell small-12 medium-6 large-4">
                    <div class="box__frame frame">
                        <div class="box__img">
                            <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($image_alt); ?>" />
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <?php if ($about_section_content) :
                $content_paragraphs = wpautop($about_section_content);
                $paragraphs = explode('</p>', $content_paragraphs);
                $visible_paragraphs = array_slice($paragraphs, 0, 2);
                $hidden_paragraphs = array_slice($paragraphs, 2);
            ?>
                <div class="cell small-12 medium-6 large-8">
                    <div class="box__info">
                        <?php echo implode('</p>', $visible_paragraphs); ?>

                        <div class="box__hidden">
                            <?php echo implode('</p>', $hidden_paragraphs); ?>
                        </div>

                        <?php if (!empty($hidden_paragraphs)): ?>
                        <?php if (!empty($read_more_text)): ?>
                        <button class="read-more-btn box__btn-more"><?php echo esc_html($read_more_text); ?></button>
                        <?php endif; ?>

                        <?php if (!empty($read_less_text)): ?>
                        <button class="read-more-btn box__btn-less"><?php echo esc_html($read_less_text); ?></button>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php
        $comfort_items = carbon_get_post_meta($page_id, 'comfort_repeater');

        if ($comfort_items) :
        ?>
    <section class="comfort">
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <?php foreach ($comfort_items as $item) : 
                $image_url = isset($item['comfort_item_image']) ? wp_get_attachment_image_url($item['comfort_item_image'], 'full') : '';
                $image_alt = isset($item['comfort_item_image']) ? get_post_meta($item['comfort_item_image'], '_wp_attachment_image_alt', true) : '';
                $text = isset($item['comfort_item_text']) ? $item['comfort_item_text'] : '';
                
                if (empty($image_url) && empty($text)) {
                    continue;
                }
            ?>
                <div class="cell small-12 medium-6 large-3">
                    <div class="comfort__wrap">
                        <?php if ($image_url) : ?>
                        <div class="comfort__icon">
                            <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($image_alt); ?>">
                        </div>
                        <?php endif; ?>
                        <?php if ($text) : ?>
                        <h3 class="comfort__title"><?php echo esc_html($text); ?></h3>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php
    $section_title = carbon_get_post_meta($page_id, 'our_services_title');
    $services = carbon_get_post_meta($page_id, 'our_services_repeater');
    
    if (!empty($section_title) && !empty($services)) : ?>
    <section class="our-services">
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell">
                    <div class="title">
                        <h2 class="title__wrap"><?php echo esc_html($section_title); ?></h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="our-services__items">
            <div class="grid-container">
                <div class="grid-x grid-padding-x">
                    <?php foreach ($services as $service) :
                    $image_url = isset($service['our_services_image']) ? wp_get_attachment_image_url($service['our_services_image'], 'full') : '';
                    $image_alt = isset($service['our_services_image']) ? get_post_meta($service['our_services_image'], '_wp_attachment_image_alt', true) : '';
                    $text = isset($service['our_services_text']) ? $service['our_services_text'] : '';

                    if (empty($image_url) && empty($text)) {
                        continue;
                    }
                    ?>
                    <div class="cell small-12 medium-6 large-4">
                        <div class="our-services__item">
                            <div class="frame">
                                <?php if ($image_url) : ?>
                                <div class="our-services__img">
                                    <img src="<?php echo esc_url($image_url); ?>"
                                        alt="<?php echo esc_attr($image_alt); ?>">
                                </div>
                                <?php endif; ?>
                            </div>
                            <div class="our-services__title">
                                <?php if ($text) : ?>
                                <h3 class="our-services__title-wrap"><?php echo esc_html($text); ?></h3>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php
        $brands = carbon_get_post_meta($page_id, 'brands_repeater');

        if (!empty($brands)) : ?>
    <div class="brands">
        <div class="grid-container">
            <div class="brands__slider">
                <?php foreach ($brands as $brand) :
                    $image_url = isset($brand['brands_item_image']) ? wp_get_attachment_image_url($brand['brands_item_image'], 'full') : '';
                    if (empty($image_url)) {
                        continue;
                    }
                ?>
                <div class="brands__wrap">
                    <div class="brands__img">
                        <img src="<?php echo esc_url($image_url); ?>" alt="Brand">
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php
        $title = carbon_get_post_meta($page_id, 'our_accomplishments_title');
        $image_id = carbon_get_post_meta($page_id, 'our_accomplishments_image');
        $content = carbon_get_post_meta($page_id, 'our_accomplishments_content');
        $button_name = carbon_get_post_meta($page_id, 'our_accomplishments_button_name'); 

        if (!empty($title) && !empty($image_id) && !empty($content) && !empty($button_name)) :
            $image_url = wp_get_attachment_image_url($image_id, 'full');
            $image_alt = get_post_meta($image_id, '_wp_attachment_image_alt', true);

            if (empty($image_url)) {
                $image_url = ''; 
            }

            if (empty($image_alt)) {
                $image_alt = ''; 
            }
        ?>
    <section class="box accomplishments">
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell">
                    <div class="title">
                        <h2 class="title__wrap"><?php echo esc_html($title); ?></h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="box__container grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell small-12 medium-6 large-4">
                    <div class="box__frame frame accomplishments__frame">
                        <div class="box__img accomplishments__img">
                            <?php if (!empty($image_url)) : ?>
                            <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($image_alt); ?>">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="cell small-12 medium-6 large-8">
                    <div class="box__info accomplishments__info">
                        <?php if (!empty($content)) : ?>
                        <p><?php echo esc_html($content); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="accomplishments__btn btn">
                        <?php if (!empty($button_name)) : ?>
                        <a href="#popup" class="btn__wrap"
                            data-fancybox="popup"><?php echo esc_html($button_name); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php
        $title = carbon_get_post_meta($page_id, 'our_works_title');
        $gallery = carbon_get_post_meta($page_id, 'media_gallery');

if (!empty($title)) : ?>
    <section class="our-works">
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell">
                    <div class="title">
                        <h2 class="title__wrap"><?php echo esc_html($title); ?></h2>
                    </div>
                </div>
            </div>
        </div>

        <?php
        if (!empty($gallery)) : ?>
        <div class="our-works__items">
            <div class="grid-container">
                <div class="grid-x grid-padding-x">
                    <?php foreach ($gallery as $item) :
                            $image_id = $item['gallery_image'];
                            $image_url = wp_get_attachment_image_url($image_id, 'full');
                            $image_alt = get_post_meta($image_id, '_wp_attachment_image_alt', true);
                            
                            if (empty($image_url)) {
                                continue;
                            }
                        ?>
                    <div class="cell small-12 medium-6 large-4">
                        <div class="our-services__item">
                            <div class="our-works__img">
                                <a href="<?php echo esc_url($image_url); ?>" data-fancybox="gallery">
                                    <img src="<?php echo esc_url($image_url); ?>"
                                        alt="<?php echo esc_attr($image_alt); ?>">
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </section>
    <?php endif; ?>
</main>

<?php the_content(); ?>

<?php get_footer(); ?>