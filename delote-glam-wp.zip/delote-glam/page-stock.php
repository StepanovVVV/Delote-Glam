<?php
/*
Template Name: Page Stock
*/
get_header();
?>

<main class="main-wrapper main-top">
    <section class="prices section-top stock">
        <?php if (get_the_title()) : ?>
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="cell">
                    <div class="title">
                        <h1 class="title__wrap"><?php the_title(); ?></h1>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php
            $stock_items = carbon_get_the_post_meta('stock_repeater'); 
            $has_valid_content = false; 

            if ($stock_items) : 
                $valid_stock_items = [];

                foreach ($stock_items as $stock) :
                    $stock_image_id = !empty($stock['stock_item_image']) ? $stock['stock_item_image'] : '';
                    $stock_image = $stock_image_id ? wp_get_attachment_image_url($stock_image_id, 'full') : '';
                    $stock_image_alt = $stock_image_id ? get_post_meta($stock_image_id, '_wp_attachment_image_alt', true) : ''; 
                    $stock_reverse = isset($stock['stock_reverse']) ? $stock['stock_reverse'] : false;
                    $highlight_class = $stock_reverse === true ? 'grid-x-reverse' : ''; 

                    $has_valid_details = false;
                    if (!empty($stock['stock_details'])) {
                        foreach ($stock['stock_details'] as $detail) {
                            if (!empty($detail['stock_detail_name']) || !empty($detail['stock_detail_description']) || !empty($detail['stock_detail_sale'])) {
                                $has_valid_details = true;
                                break;  
                            }
                        }
                    }

                    if (!empty($stock_image) && $has_valid_details) {
                        $valid_stock_items[] = [
                            'stock_image' => $stock_image,
                            'stock_image_alt' => $stock_image_alt,
                            'highlight_class' => $highlight_class,
                            'stock_details' => $stock['stock_details'],
                        ];
                    }
                endforeach;

                if (!empty($valid_stock_items)) :
            ?>
        <div class="prices__container grid-container">
            <?php
    foreach ($valid_stock_items as $valid_stock) :
        ?>
            <div class="grid-x grid-padding-x <?php echo esc_attr($valid_stock['highlight_class']); ?>">
                <div class="cell small-12 medium-6 large-5">
                    <div class="prices__img">
                        <?php if (!empty($valid_stock['stock_image'])) : ?>
                        <img src="<?php echo esc_url($valid_stock['stock_image']); ?>"
                            alt="<?php echo esc_attr($valid_stock['stock_image_alt']); ?>">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="cell small-12 medium-6 large-7">
                    <div class="prices__wrap stock__wrap">
                        <div class="prices__info">
                            <?php
                        foreach ($valid_stock['stock_details'] as $detail) :
                            $stock_name = !empty($detail['stock_detail_name']) ? $detail['stock_detail_name'] : '';
                            $stock_description = !empty($detail['stock_detail_description']) ? $detail['stock_detail_description'] : '';
                            $stock_sale = !empty($detail['stock_detail_sale']) ? $detail['stock_detail_sale'] : '';

                            if (!empty($stock_name) || !empty($stock_description) || !empty($stock_sale)) :
                                ?>
                            <div class="prices__info-wrap">
                                <?php if (!empty($stock_name)) : ?>
                                <div class="prices__name">
                                    <h3><?php echo esc_html($stock_name); ?></h3>
                                    <?php if (!empty($stock_description)) : ?>
                                    <p><?php echo esc_html($stock_description); ?></p>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>

                                <?php if (!empty($stock_sale)) : ?>
                                <div class="prices__price">
                                    <?php echo esc_html($stock_sale); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php
                            endif;
                        endforeach;
                        ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php
    endforeach;
    ?>
        </div>
        <?php 
    endif; 
endif; 
?>
    </section>
</main>

<?php
    // Output the page content
    the_content();
?>

<?php get_footer(); ?>